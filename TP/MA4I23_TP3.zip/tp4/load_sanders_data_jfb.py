import pandas as pd
import os
import collections
import csv
import json

import numpy as np


DATA_DIR = "data"

def load_sanders_data_jfb(dirname=".", line_count=-1, verbose=False):
    count = 0

    topics = []
    labels = []
    tweets = []
    
    SandersData=pd.DataFrame(columns=['topic', 'label', 'tweet'])
    
    with open(os.path.join(DATA_DIR, dirname, "corpus_old.csv"), "r") as csvfile:
        metareader = csv.reader(csvfile, delimiter=',', quotechar='"')
        for line in metareader:
            count += 1
            if line_count > 0 and count > line_count:
                break

            topic, label, tweet_id = line[0:3]

            tweet_fn = os.path.join(
                DATA_DIR, dirname, 'rawdata', '%s.json' % tweet_id)
            try:
                tweet = json.load(open(tweet_fn, "r"))
            except IOError:
                if verbose: print(("Tweet '%s' not found. Skip."%tweet_fn))
                continue
            n=0
            if 'text' in tweet and tweet['user']['lang'] == "en":
               
                topics.append(topic)
                labels.append(label)
                tweets.append(tweet['text'])
                """SandersData['topic'][n]=topic
                SandersData['label'][n]=label
                SandersData['tweet'][n]=tweet['text']
                n+=1
                """
            else:
                if verbose: print("This tweet was not in english")
                
    SandersData=pd.DataFrame(data=np.array([topics, labels, tweets]).T,  columns=['topic', 'label', 'tweet'])
    return tweets, labels, topics, SandersData

tweets, labels, topics, S=load_sanders_data_jfb()
#Sauvegarde des tweets
S.to_csv("SandersData.csv", index=False)